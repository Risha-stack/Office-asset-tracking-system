USE agriculture_management_db;

-- Admin user (password: admin123)
INSERT INTO admin (username, password) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Farmer users (password: password123)
INSERT INTO users (fullname, email, password, farm_location) VALUES 
('John Doe', 'john@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Green Valley Farm'),
('Jane Smith', 'jane@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Sunny Fields');

-- Crops
INSERT INTO crops (user_id, crop_name, crop_category, planting_date, harvest_date, soil_type, water_requirement, fertilizer_used) VALUES 
(1, 'Rice', 'Cereal', '2025-06-01', '2025-11-01', 'Clay', 'High', 'Urea, NPK'),
(1, 'Wheat', 'Cereal', '2025-11-15', '2026-04-15', 'Loamy', 'Medium', 'DAP'),
(2, 'Sugarcane', 'Cash Crop', '2025-03-01', '2026-02-01', 'Alluvial', 'High', 'NPK');

-- Irrigation Schedule
INSERT INTO irrigation_schedule (crop_id, irrigation_date, water_quantity, status) VALUES 
(1, '2025-06-15', '1000 Liters', 'Completed'),
(1, '2025-07-01', '1200 Liters', 'Pending'),
(2, '2025-12-01', '800 Liters', 'Completed');

-- Fertilizers
INSERT INTO fertilizers (fertilizer_name, crop_type, quantity, instructions) VALUES 
('Urea', 'Rice', '50 kg/acre', 'Apply in two split doses.'),
('DAP', 'Wheat', '40 kg/acre', 'Apply at the time of sowing.'),
('NPK (10:26:26)', 'Sugarcane', '60 kg/acre', 'Basal application required.');

-- Production
INSERT INTO production (crop_id, harvest_date, quantity_produced, market_price) VALUES 
(1, '2025-11-05', 2500.00, 20.50),
(3, '2026-02-10', 80000.00, 3.20);
