CREATE DATABASE IF NOT EXISTS agriculture_management_db;
USE agriculture_management_db;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    farm_location VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE crops (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    crop_name VARCHAR(255) NOT NULL,
    crop_category VARCHAR(100) NOT NULL,
    planting_date DATE NOT NULL,
    harvest_date DATE NOT NULL,
    soil_type VARCHAR(100) NOT NULL,
    water_requirement VARCHAR(100) NOT NULL,
    fertilizer_used VARCHAR(255),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE irrigation_schedule (
    id INT AUTO_INCREMENT PRIMARY KEY,
    crop_id INT NOT NULL,
    irrigation_date DATE NOT NULL,
    water_quantity VARCHAR(100) NOT NULL,
    status ENUM('Pending', 'Completed') DEFAULT 'Pending',
    FOREIGN KEY (crop_id) REFERENCES crops(id) ON DELETE CASCADE
);

CREATE TABLE fertilizers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fertilizer_name VARCHAR(255) NOT NULL,
    crop_type VARCHAR(100) NOT NULL,
    quantity VARCHAR(100) NOT NULL,
    instructions TEXT
);

CREATE TABLE production (
    id INT AUTO_INCREMENT PRIMARY KEY,
    crop_id INT NOT NULL,
    harvest_date DATE NOT NULL,
    quantity_produced DECIMAL(10,2) NOT NULL,
    market_price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (crop_id) REFERENCES crops(id) ON DELETE CASCADE
);

CREATE TABLE contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
