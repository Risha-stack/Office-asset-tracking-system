<?php
// dashboard.php
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/session.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$fullname = $_SESSION['fullname'];

// Fetch Stats
$total_crops = $conn->query("SELECT COUNT(*) as count FROM crops WHERE user_id = $user_id")->fetch_assoc()['count'];
$pending_irrigation = $conn->query("SELECT COUNT(*) as count FROM irrigation_schedule i JOIN crops c ON i.crop_id = c.id WHERE c.user_id = $user_id AND i.status = 'Pending'")->fetch_assoc()['count'];
$total_production = $conn->query("SELECT SUM(quantity_produced) as total FROM production p JOIN crops c ON p.crop_id = c.id WHERE c.user_id = $user_id")->fetch_assoc()['total'];
$total_production = $total_production ? $total_production : 0;

include 'includes/header.php';
?>

<style>
    .dashboard-container {
        padding: 40px 0;
    }
    .welcome-banner {
        background: var(--dark-green);
        color: var(--white);
        padding: 30px;
        border-radius: var(--border-radius);
        margin-bottom: 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .welcome-banner h2 {
        color: var(--white);
        margin-bottom: 5px;
    }
    .welcome-banner p {
        color: #ddd;
    }
    
    .dashboard-grid {
        display: grid;
        grid-template-columns: 3fr 1fr;
        gap: 30px;
    }
    @media (max-width: 992px) {
        .dashboard-grid {
            grid-template-columns: 1fr;
        }
    }
    
    .panel {
        background: var(--white);
        padding: 25px;
        border-radius: var(--border-radius);
        box-shadow: var(--shadow);
        margin-bottom: 30px;
    }
    .panel h3 {
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 1px solid var(--gray-bg);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .table-responsive {
        overflow-x: auto;
    }
    table {
        width: 100%;
        border-collapse: collapse;
    }
    th, td {
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid var(--gray-bg);
    }
    th {
        background-color: var(--gray-bg);
        color: var(--dark-green);
        font-weight: 600;
    }
    
    .badge {
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 500;
    }
    .badge-pending { background: #fff3cd; color: #856404; }
    .badge-completed { background: #d4edda; color: #155724; }
    
    .quick-actions a {
        display: block;
        padding: 12px;
        background: var(--gray-bg);
        color: var(--text-dark);
        border-radius: var(--border-radius);
        margin-bottom: 10px;
        transition: var(--transition);
        font-weight: 500;
    }
    .quick-actions a:hover {
        background: var(--primary-green);
        color: var(--white);
    }
    .quick-actions a i {
        margin-right: 10px;
        width: 20px;
    }
</style>

<div class="container dashboard-container fade-in">
    <div class="welcome-banner slide-up">
        <div>
            <h2>Welcome back, <?= htmlspecialchars($fullname) ?>!</h2>
            <p>Here's what's happening on your farm today.</p>
        </div>
        <div>
            <i class="fas fa-tractor" style="font-size: 40px; opacity: 0.8;"></i>
        </div>
    </div>

    <div class="dashboard-stats-grid slide-up delay-1">
        <div class="stat-card">
            <div class="icon"><i class="fas fa-seedling"></i></div>
            <div class="info">
                <h4>Total Crops</h4>
                <h2><?= $total_crops ?></h2>
            </div>
        </div>
        <div class="stat-card">
            <div class="icon"><i class="fas fa-tint"></i></div>
            <div class="info">
                <h4>Pending Irrigation</h4>
                <h2><?= $pending_irrigation ?></h2>
            </div>
        </div>
        <div class="stat-card">
            <div class="icon"><i class="fas fa-chart-line"></i></div>
            <div class="info">
                <h4>Total Production</h4>
                <h2><?= number_format($total_production, 2) ?> kg</h2>
            </div>
        </div>
    </div>

    <div class="dashboard-grid slide-up delay-2">
        <div class="main-content">
            <div class="panel">
                <h3>Recent Crops <a href="add_crop.php" class="btn btn-primary" style="padding: 5px 15px; font-size: 0.9rem;"><i class="fas fa-plus"></i> Add Crop</a></h3>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Crop Name</th>
                                <th>Category</th>
                                <th>Planting Date</th>
                                <th>Harvest Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $crops_query = "SELECT * FROM crops WHERE user_id = $user_id ORDER BY id DESC LIMIT 5";
                            $crops_result = $conn->query($crops_query);
                            
                            if ($crops_result->num_rows > 0) {
                                while($crop = $crops_result->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>{$crop['crop_name']}</td>";
                                    echo "<td>{$crop['crop_category']}</td>";
                                    echo "<td>{$crop['planting_date']}</td>";
                                    echo "<td>{$crop['harvest_date']}</td>";
                                    echo "<td><a href='edit_crop.php?id={$crop['id']}' style='color: var(--secondary-green);'><i class='fas fa-edit'></i></a></td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='5' style='text-align: center;'>No crops added yet.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="panel">
                <h3>Upcoming Irrigation</h3>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Crop</th>
                                <th>Date</th>
                                <th>Water Qty</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $irr_query = "SELECT i.*, c.crop_name FROM irrigation_schedule i JOIN crops c ON i.crop_id = c.id WHERE c.user_id = $user_id AND i.status = 'Pending' ORDER BY i.irrigation_date ASC LIMIT 5";
                            $irr_result = $conn->query($irr_query);
                            
                            if ($irr_result->num_rows > 0) {
                                while($irr = $irr_result->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>{$irr['crop_name']}</td>";
                                    echo "<td>{$irr['irrigation_date']}</td>";
                                    echo "<td>{$irr['water_quantity']}</td>";
                                    echo "<td><span class='badge badge-pending'>{$irr['status']}</span></td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='4' style='text-align: center;'>No pending irrigation schedules.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="sidebar">
            <div class="panel">
                <h3>Quick Actions</h3>
                <div class="quick-actions">
                    <a href="add_crop.php"><i class="fas fa-seedling"></i> Add New Crop</a>
                    <a href="irrigation.php"><i class="fas fa-tint"></i> Manage Irrigation</a>
                    <a href="fertilizer.php"><i class="fas fa-flask"></i> Fertilizer Usage</a>
                    <a href="production.php"><i class="fas fa-chart-bar"></i> Record Production</a>
                    <a href="profile.php"><i class="fas fa-user-circle"></i> My Profile</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
