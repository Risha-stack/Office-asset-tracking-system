<?php
// production.php
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/session.php';
requireLogin();

$user_id = $_SESSION['user_id'];

include 'includes/header.php';
?>

<div class="container fade-in" style="padding: 40px 0;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2>Production Records</h2>
        <div>
            <a href="add_production.php" class="btn btn-primary"><i class="fas fa-plus"></i> Add Record</a>
            <a href="dashboard.php" class="btn btn-outline">Back to Dashboard</a>
        </div>
    </div>

    <div class="card">
        <div class="table-responsive">
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr>
                        <th style="padding: 12px; background: var(--gray-bg); text-align: left;">Crop Name</th>
                        <th style="padding: 12px; background: var(--gray-bg); text-align: left;">Harvest Date</th>
                        <th style="padding: 12px; background: var(--gray-bg); text-align: left;">Quantity (kg)</th>
                        <th style="padding: 12px; background: var(--gray-bg); text-align: left;">Market Price / kg</th>
                        <th style="padding: 12px; background: var(--gray-bg); text-align: left;">Total Value</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT p.*, c.crop_name FROM production p JOIN crops c ON p.crop_id = c.id WHERE c.user_id = $user_id ORDER BY p.harvest_date DESC";
                    $result = $conn->query($query);
                    $total_revenue = 0;
                    
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            $value = $row['quantity_produced'] * $row['market_price'];
                            $total_revenue += $value;
                            echo "<tr style='border-bottom: 1px solid var(--gray-bg);'>";
                            echo "<td style='padding: 12px;'>{$row['crop_name']}</td>";
                            echo "<td style='padding: 12px;'>{$row['harvest_date']}</td>";
                            echo "<td style='padding: 12px;'>{$row['quantity_produced']}</td>";
                            echo "<td style='padding: 12px;'>$" . number_format($row['market_price'], 2) . "</td>";
                            echo "<td style='padding: 12px; font-weight: bold; color: var(--primary-green);'>$" . number_format($value, 2) . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5' style='text-align: center; padding: 20px;'>No production records found.</td></tr>";
                    }
                    ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="4" style="text-align: right; padding: 15px;">Estimated Total Revenue:</th>
                        <th style="padding: 15px; font-size: 1.2rem; color: var(--dark-green);">$<?= number_format($total_revenue, 2) ?></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
