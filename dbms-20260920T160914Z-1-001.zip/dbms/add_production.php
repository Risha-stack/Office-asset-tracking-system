<?php
// add_production.php
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/session.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$success_msg = '';
$error_msg = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $crop_id = (int)$_POST['crop_id'];
    $harvest_date = sanitizeInput($_POST['harvest_date']);
    $quantity_produced = (float)$_POST['quantity_produced'];
    $market_price = (float)$_POST['market_price'];

    // Verify crop belongs to user
    $verify = $conn->query("SELECT id FROM crops WHERE id = $crop_id AND user_id = $user_id");
    if ($verify->num_rows > 0) {
        $sql = "INSERT INTO production (crop_id, harvest_date, quantity_produced, market_price) VALUES ($crop_id, '$harvest_date', $quantity_produced, $market_price)";
        if ($conn->query($sql) === TRUE) {
            $success_msg = "Production record added successfully!";
        } else {
            $error_msg = "Error: " . $conn->error;
        }
    } else {
        $error_msg = "Invalid crop selected.";
    }
}

// Fetch user's crops
$crops_result = $conn->query("SELECT id, crop_name FROM crops WHERE user_id = $user_id");

include 'includes/header.php';
?>

<div class="container fade-in" style="padding: 40px 0;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2>Add Production Record</h2>
        <a href="production.php" class="btn btn-outline">Back to Records</a>
    </div>

    <div class="card" style="max-width: 600px; margin: 0 auto;">
        <?php 
            if(!empty($success_msg)) echo displayAlert($success_msg, 'success');
            if(!empty($error_msg)) echo displayAlert($error_msg, 'error');
        ?>
        
        <form action="add_production.php" method="POST">
            <div class="form-group">
                <label>Select Crop *</label>
                <select name="crop_id" class="form-control" required>
                    <option value="">-- Select Crop --</option>
                    <?php
                    if ($crops_result->num_rows > 0) {
                        while($crop = $crops_result->fetch_assoc()) {
                            echo "<option value='{$crop['id']}'>{$crop['crop_name']}</option>";
                        }
                    } else {
                        echo "<option value='' disabled>No crops found. Please add a crop first.</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>Harvest Date *</label>
                <input type="date" name="harvest_date" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Quantity Produced (in kg) *</label>
                <input type="number" step="0.01" name="quantity_produced" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Current Market Price per kg *</label>
                <input type="number" step="0.01" name="market_price" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%;">Save Record</button>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
