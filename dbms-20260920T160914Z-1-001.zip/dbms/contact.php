<?php
// contact.php
require_once 'includes/db.php';
require_once 'includes/functions.php';

$success_msg = '';
$error_msg = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = sanitizeInput($_POST['name']);
    $email = sanitizeInput($_POST['email']);
    $phone = sanitizeInput($_POST['phone']);
    $message = sanitizeInput($_POST['message']);

    if (empty($name) || empty($email) || empty($message)) {
        $error_msg = "Please fill all required fields.";
    } else {
        $sql = "INSERT INTO contact_messages (name, email, phone, message) VALUES ('$name', '$email', '$phone', '$message')";
        if ($conn->query($sql) === TRUE) {
            $success_msg = "Thank you! Your message has been sent successfully.";
        } else {
            $error_msg = "Error: " . $conn->error;
        }
    }
}

include 'includes/header.php';
?>

<style>
    .page-header {
        background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('images/hero/farming-bg.jpg') no-repeat center center/cover;
        height: 300px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--white);
        text-align: center;
    }
    .page-header h1 {
        font-size: 2.5rem;
        color: var(--white);
        margin-bottom: 10px;
    }
    .breadcrumb {
        font-size: 1rem;
    }
    .breadcrumb a {
        color: var(--secondary-green);
    }
    .contact-container {
        display: flex;
        gap: 50px;
        padding: 80px 0;
    }
    .contact-info {
        flex: 1;
    }
    .contact-form {
        flex: 1;
        background: var(--white);
        padding: 40px;
        border-radius: var(--border-radius);
        box-shadow: var(--shadow);
    }
    .info-item {
        display: flex;
        align-items: flex-start;
        gap: 20px;
        margin-bottom: 30px;
    }
    .info-item .icon {
        width: 50px;
        height: 50px;
        background: var(--gray-bg);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--primary-green);
        font-size: 20px;
    }
</style>

<div class="page-header fade-in">
    <div class="container">
        <h1>Contact Us</h1>
        <div class="breadcrumb">
            <a href="index.php">Home</a> / Contact
        </div>
    </div>
</div>

<div class="container">
    <div class="contact-container">
        <div class="contact-info fade-in">
            <h2 style="color: var(--dark-green); margin-bottom: 30px;">Get In Touch</h2>
            <p style="color: var(--text-light); margin-bottom: 40px;">Have questions about our Smart Agricultural Management System? We're here to help! Fill out the form or reach out to us directly.</p>
            
            <div class="info-item">
                <div class="icon"><i class="fas fa-map-marker-alt"></i></div>
                <div>
                    <h4>Location</h4>
                    <p style="color: var(--text-light);">123 Agri-Tech Park, Green City, State 45678</p>
                </div>
            </div>
            <div class="info-item">
                <div class="icon"><i class="fas fa-envelope"></i></div>
                <div>
                    <h4>Email Us</h4>
                    <p style="color: var(--text-light);">info@agroculture.com<br>support@agroculture.com</p>
                </div>
            </div>
            <div class="info-item">
                <div class="icon"><i class="fas fa-phone-alt"></i></div>
                <div>
                    <h4>Call Us</h4>
                    <p style="color: var(--text-light);">+91 98765 43210<br>+91 12345 67890</p>
                </div>
            </div>
        </div>
        
        <div class="contact-form fade-in delay-1">
            <h3 style="margin-bottom: 25px; color: var(--dark-green);">Send a Message</h3>
            
            <?php 
                if(!empty($success_msg)) echo displayAlert($success_msg, 'success');
                if(!empty($error_msg)) echo displayAlert($error_msg, 'error');
            ?>
            
            <form action="contact.php" method="POST" onsubmit="return validateContactForm()">
                <div class="form-group">
                    <label>Full Name *</label>
                    <input type="text" name="name" id="name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Email Address *</label>
                    <input type="email" name="email" id="email" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="text" name="phone" class="form-control">
                </div>
                <div class="form-group">
                    <label>Message *</label>
                    <textarea name="message" id="message" rows="5" class="form-control" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary" style="width: 100%;">Send Message</button>
            </form>
        </div>
    </div>
</div>

<script>
function validateContactForm() {
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let message = document.getElementById("message").value;
    if (name == "" || email == "" || message == "") {
        alert("Please fill all required fields.");
        return false;
    }
    return true;
}
</script>

<?php include 'includes/footer.php'; ?>
