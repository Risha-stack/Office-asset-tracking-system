<?php
// irrigation.php
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/session.php';
requireLogin();

$user_id = $_SESSION['user_id'];

// Handle status update
if (isset($_GET['complete_id'])) {
    $complete_id = (int)$_GET['complete_id'];
    // Verify ownership
    $verify = $conn->query("SELECT i.id FROM irrigation_schedule i JOIN crops c ON i.crop_id = c.id WHERE i.id = $complete_id AND c.user_id = $user_id");
    if ($verify->num_rows > 0) {
        $conn->query("UPDATE irrigation_schedule SET status = 'Completed' WHERE id = $complete_id");
        header("Location: irrigation.php");
        exit();
    }
}

include 'includes/header.php';
?>

<div class="container fade-in" style="padding: 40px 0;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2>Irrigation Schedules</h2>
        <div>
            <a href="add_irrigation.php" class="btn btn-primary"><i class="fas fa-plus"></i> Add Schedule</a>
            <a href="dashboard.php" class="btn btn-outline">Back to Dashboard</a>
        </div>
    </div>

    <div class="card">
        <div class="table-responsive">
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr>
                        <th style="padding: 12px; background: var(--gray-bg); text-align: left;">Crop Name</th>
                        <th style="padding: 12px; background: var(--gray-bg); text-align: left;">Irrigation Date</th>
                        <th style="padding: 12px; background: var(--gray-bg); text-align: left;">Water Quantity</th>
                        <th style="padding: 12px; background: var(--gray-bg); text-align: left;">Status</th>
                        <th style="padding: 12px; background: var(--gray-bg); text-align: left;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT i.*, c.crop_name FROM irrigation_schedule i JOIN crops c ON i.crop_id = c.id WHERE c.user_id = $user_id ORDER BY i.irrigation_date ASC";
                    $result = $conn->query($query);
                    
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            $status_class = $row['status'] == 'Pending' ? 'badge-pending' : 'badge-completed';
                            echo "<tr style='border-bottom: 1px solid var(--gray-bg);'>";
                            echo "<td style='padding: 12px;'>{$row['crop_name']}</td>";
                            echo "<td style='padding: 12px;'>{$row['irrigation_date']}</td>";
                            echo "<td style='padding: 12px;'>{$row['water_quantity']}</td>";
                            echo "<td style='padding: 12px;'><span class='badge {$status_class}'>{$row['status']}</span></td>";
                            echo "<td style='padding: 12px;'>";
                            if ($row['status'] == 'Pending') {
                                echo "<a href='irrigation.php?complete_id={$row['id']}' class='btn btn-primary' style='padding: 5px 10px; font-size: 0.8rem;'>Mark Done</a>";
                            }
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5' style='text-align: center; padding: 20px;'>No irrigation schedules found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
