<?php
// add_crop.php
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/session.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$success_msg = '';
$error_msg = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $crop_name = sanitizeInput($_POST['crop_name']);
    $crop_category = sanitizeInput($_POST['crop_category']);
    $planting_date = sanitizeInput($_POST['planting_date']);
    $harvest_date = sanitizeInput($_POST['harvest_date']);
    $soil_type = sanitizeInput($_POST['soil_type']);
    $water_requirement = sanitizeInput($_POST['water_requirement']);
    $fertilizer_used = sanitizeInput($_POST['fertilizer_used']);

    $sql = "INSERT INTO crops (user_id, crop_name, crop_category, planting_date, harvest_date, soil_type, water_requirement, fertilizer_used) 
            VALUES ('$user_id', '$crop_name', '$crop_category', '$planting_date', '$harvest_date', '$soil_type', '$water_requirement', '$fertilizer_used')";
            
    if ($conn->query($sql) === TRUE) {
        $success_msg = "Crop added successfully!";
    } else {
        $error_msg = "Error: " . $conn->error;
    }
}

include 'includes/header.php';
?>

<div class="container fade-in" style="padding: 40px 0;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2>Add New Crop</h2>
        <a href="dashboard.php" class="btn btn-outline">Back to Dashboard</a>
    </div>

    <div class="card" style="max-width: 800px; margin: 0 auto;">
        <?php 
            if(!empty($success_msg)) echo displayAlert($success_msg, 'success');
            if(!empty($error_msg)) echo displayAlert($error_msg, 'error');
        ?>
        
        <form action="add_crop.php" method="POST">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label>Crop Name *</label>
                    <input type="text" name="crop_name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Crop Category *</label>
                    <select name="crop_category" class="form-control" required>
                        <option value="">Select Category</option>
                        <option value="Cereal">Cereal</option>
                        <option value="Pulses">Pulses</option>
                        <option value="Vegetables">Vegetables</option>
                        <option value="Fruits">Fruits</option>
                        <option value="Cash Crop">Cash Crop</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Planting Date *</label>
                    <input type="date" name="planting_date" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Expected Harvest Date *</label>
                    <input type="date" name="harvest_date" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Soil Type *</label>
                    <input type="text" name="soil_type" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Water Requirement *</label>
                    <select name="water_requirement" class="form-control" required>
                        <option value="Low">Low</option>
                        <option value="Medium">Medium</option>
                        <option value="High">High</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label>Fertilizer Recommended/Used</label>
                <input type="text" name="fertilizer_used" class="form-control" placeholder="e.g. Urea, NPK">
            </div>
            <button type="submit" class="btn btn-primary">Save Crop Details</button>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
