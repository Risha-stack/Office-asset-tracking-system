<?php
// fertilizer.php
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/session.php';
requireLogin();

include 'includes/header.php';
?>

<div class="container fade-in" style="padding: 40px 0;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2>Fertilizer Recommendations</h2>
        <a href="dashboard.php" class="btn btn-outline">Back to Dashboard</a>
    </div>

    <div class="card">
        <p style="margin-bottom: 20px; color: var(--text-light);">Here are the general fertilizer recommendations based on crop types. For personalized recommendations, please contact our experts.</p>
        
        <div class="table-responsive">
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr>
                        <th style="padding: 12px; background: var(--gray-bg); text-align: left;">Fertilizer Name</th>
                        <th style="padding: 12px; background: var(--gray-bg); text-align: left;">Recommended Crop</th>
                        <th style="padding: 12px; background: var(--gray-bg); text-align: left;">Standard Quantity</th>
                        <th style="padding: 12px; background: var(--gray-bg); text-align: left;">Instructions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT * FROM fertilizers";
                    $result = $conn->query($query);
                    
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr style='border-bottom: 1px solid var(--gray-bg);'>";
                            echo "<td style='padding: 12px; font-weight: 500; color: var(--dark-green);'>{$row['fertilizer_name']}</td>";
                            echo "<td style='padding: 12px;'>{$row['crop_type']}</td>";
                            echo "<td style='padding: 12px;'>{$row['quantity']}</td>";
                            echo "<td style='padding: 12px;'>{$row['instructions']}</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4' style='text-align: center; padding: 20px;'>No fertilizer data found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
