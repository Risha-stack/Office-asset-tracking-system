<?php
// add_irrigation.php
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/session.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$success_msg = '';
$error_msg = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $crop_id = (int)$_POST['crop_id'];
    $irrigation_date = sanitizeInput($_POST['irrigation_date']);
    $water_quantity = sanitizeInput($_POST['water_quantity']);

    // Verify crop belongs to user
    $verify = $conn->query("SELECT id FROM crops WHERE id = $crop_id AND user_id = $user_id");
    if ($verify->num_rows > 0) {
        $sql = "INSERT INTO irrigation_schedule (crop_id, irrigation_date, water_quantity) VALUES ($crop_id, '$irrigation_date', '$water_quantity')";
        if ($conn->query($sql) === TRUE) {
            $success_msg = "Irrigation schedule added successfully!";
        } else {
            $error_msg = "Error: " . $conn->error;
        }
    } else {
        $error_msg = "Invalid crop selected.";
    }
}

// Fetch user's crops
$crops_result = $conn->query("SELECT id, crop_name FROM crops WHERE user_id = $user_id");

include 'includes/header.php';
?>

<div class="container fade-in" style="padding: 40px 0;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2>Add Irrigation Schedule</h2>
        <a href="irrigation.php" class="btn btn-outline">Back to Schedules</a>
    </div>

    <div class="card" style="max-width: 600px; margin: 0 auto;">
        <?php 
            if(!empty($success_msg)) echo displayAlert($success_msg, 'success');
            if(!empty($error_msg)) echo displayAlert($error_msg, 'error');
        ?>
        
        <form action="add_irrigation.php" method="POST">
            <div class="form-group">
                <label>Select Crop *</label>
                <select name="crop_id" class="form-control" required>
                    <option value="">-- Select Crop --</option>
                    <?php
                    if ($crops_result->num_rows > 0) {
                        while($crop = $crops_result->fetch_assoc()) {
                            echo "<option value='{$crop['id']}'>{$crop['crop_name']}</option>";
                        }
                    } else {
                        echo "<option value='' disabled>No crops found. Please add a crop first.</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>Irrigation Date *</label>
                <input type="date" name="irrigation_date" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Water Quantity (e.g. 1000 Liters, 2 Inches) *</label>
                <input type="text" name="water_quantity" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%;">Save Schedule</button>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
