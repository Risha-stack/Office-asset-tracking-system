<?php
// edit_crop.php
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/session.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$success_msg = '';
$error_msg = '';

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}
$crop_id = $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $crop_name = sanitizeInput($_POST['crop_name']);
    $crop_category = sanitizeInput($_POST['crop_category']);
    $planting_date = sanitizeInput($_POST['planting_date']);
    $harvest_date = sanitizeInput($_POST['harvest_date']);
    $soil_type = sanitizeInput($_POST['soil_type']);
    $water_requirement = sanitizeInput($_POST['water_requirement']);
    $fertilizer_used = sanitizeInput($_POST['fertilizer_used']);

    $sql = "UPDATE crops SET crop_name='$crop_name', crop_category='$crop_category', planting_date='$planting_date', 
            harvest_date='$harvest_date', soil_type='$soil_type', water_requirement='$water_requirement', fertilizer_used='$fertilizer_used' 
            WHERE id=$crop_id AND user_id=$user_id";
            
    if ($conn->query($sql) === TRUE) {
        $success_msg = "Crop updated successfully!";
    } else {
        $error_msg = "Error: " . $conn->error;
    }
}

// Fetch existing data
$result = $conn->query("SELECT * FROM crops WHERE id=$crop_id AND user_id=$user_id");
if ($result->num_rows == 0) {
    header("Location: dashboard.php");
    exit();
}
$crop = $result->fetch_assoc();

include 'includes/header.php';
?>

<div class="container fade-in" style="padding: 40px 0;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2>Edit Crop Details</h2>
        <a href="dashboard.php" class="btn btn-outline">Back to Dashboard</a>
    </div>

    <div class="card" style="max-width: 800px; margin: 0 auto;">
        <?php 
            if(!empty($success_msg)) echo displayAlert($success_msg, 'success');
            if(!empty($error_msg)) echo displayAlert($error_msg, 'error');
        ?>
        
        <form action="edit_crop.php?id=<?= $crop_id ?>" method="POST">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label>Crop Name *</label>
                    <input type="text" name="crop_name" class="form-control" value="<?= $crop['crop_name'] ?>" required>
                </div>
                <div class="form-group">
                    <label>Crop Category *</label>
                    <select name="crop_category" class="form-control" required>
                        <option value="Cereal" <?= $crop['crop_category'] == 'Cereal' ? 'selected' : '' ?>>Cereal</option>
                        <option value="Pulses" <?= $crop['crop_category'] == 'Pulses' ? 'selected' : '' ?>>Pulses</option>
                        <option value="Vegetables" <?= $crop['crop_category'] == 'Vegetables' ? 'selected' : '' ?>>Vegetables</option>
                        <option value="Fruits" <?= $crop['crop_category'] == 'Fruits' ? 'selected' : '' ?>>Fruits</option>
                        <option value="Cash Crop" <?= $crop['crop_category'] == 'Cash Crop' ? 'selected' : '' ?>>Cash Crop</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Planting Date *</label>
                    <input type="date" name="planting_date" class="form-control" value="<?= $crop['planting_date'] ?>" required>
                </div>
                <div class="form-group">
                    <label>Expected Harvest Date *</label>
                    <input type="date" name="harvest_date" class="form-control" value="<?= $crop['harvest_date'] ?>" required>
                </div>
                <div class="form-group">
                    <label>Soil Type *</label>
                    <input type="text" name="soil_type" class="form-control" value="<?= $crop['soil_type'] ?>" required>
                </div>
                <div class="form-group">
                    <label>Water Requirement *</label>
                    <select name="water_requirement" class="form-control" required>
                        <option value="Low" <?= $crop['water_requirement'] == 'Low' ? 'selected' : '' ?>>Low</option>
                        <option value="Medium" <?= $crop['water_requirement'] == 'Medium' ? 'selected' : '' ?>>Medium</option>
                        <option value="High" <?= $crop['water_requirement'] == 'High' ? 'selected' : '' ?>>High</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label>Fertilizer Recommended/Used</label>
                <input type="text" name="fertilizer_used" class="form-control" value="<?= $crop['fertilizer_used'] ?>">
            </div>
            <button type="submit" class="btn btn-primary">Update Crop Details</button>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
