<?php
// register.php
require_once 'includes/db.php';
require_once 'includes/functions.php';
session_start();

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

$error_msg = '';
$success_msg = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = sanitizeInput($_POST['fullname']);
    $email = sanitizeInput($_POST['email']);
    $farm_location = sanitizeInput($_POST['farm_location']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password !== $confirm_password) {
        $error_msg = "Passwords do not match.";
    } else {
        $check_email = "SELECT id FROM users WHERE email = '$email'";
        if ($conn->query($check_email)->num_rows > 0) {
            $error_msg = "Email already registered.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO users (fullname, email, password, farm_location) VALUES ('$fullname', '$email', '$hashed_password', '$farm_location')";
            
            if ($conn->query($sql) === TRUE) {
                $success_msg = "Registration successful! <a href='login.php'>Login here</a>";
            } else {
                $error_msg = "Error: " . $conn->error;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register - AgroCulture</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/animations.css">
    <style>
        body {
            background-color: var(--gray-bg);
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 20px;
        }
        .auth-container {
            background: var(--white);
            padding: 40px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            width: 100%;
            max-width: 500px;
            text-align: center;
        }
        .auth-logo {
            color: var(--primary-green);
            font-size: 30px;
            margin-bottom: 20px;
            font-family: 'Montserrat', sans-serif;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="auth-container fade-in">
        <div class="auth-logo"><i class="fas fa-leaf"></i> AgroCulture</div>
        <h2 style="margin-bottom: 20px;">Create an Account</h2>
        
        <?php 
            if(!empty($error_msg)) echo displayAlert($error_msg, 'error');
            if(!empty($success_msg)) echo displayAlert($success_msg, 'success');
        ?>
        
        <form action="register.php" method="POST" style="text-align: left;">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="fullname" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Farm Location</label>
                <input type="text" name="farm_location" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required minlength="6">
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 10px;">Register</button>
        </form>
        <p style="margin-top: 20px; font-size: 0.9rem;">Already have an account? <a href="login.php">Login here</a></p>
        <p style="margin-top: 10px; font-size: 0.9rem;"><a href="index.php">Back to Home</a></p>
    </div>
</body>
</html>
