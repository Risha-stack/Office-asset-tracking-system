<?php
// login.php
require_once 'includes/db.php';
require_once 'includes/functions.php';
session_start();

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

$error_msg = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = sanitizeInput($_POST['email']);
    $password = $_POST['password'];

    $sql = "SELECT id, fullname, password FROM users WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['fullname'] = $row['fullname'];
            header("Location: dashboard.php");
            exit();
        } else {
            $error_msg = "Invalid password.";
        }
    } else {
        $error_msg = "No account found with that email.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - AgroCulture</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/animations.css">
    <style>
        body {
            background-color: var(--gray-bg);
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        .auth-container {
            background: var(--white);
            padding: 40px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }
        .auth-logo {
            color: var(--primary-green);
            font-size: 30px;
            margin-bottom: 20px;
            font-family: 'Montserrat', sans-serif;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="auth-container fade-in">
        <div class="auth-logo"><i class="fas fa-leaf"></i> AgroCulture</div>
        <h2 style="margin-bottom: 20px;">Welcome Back</h2>
        
        <?php if(!empty($error_msg)) echo displayAlert($error_msg, 'error'); ?>
        
        <form action="login.php" method="POST" style="text-align: left;">
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 10px;">Login</button>
        </form>
        <p style="margin-top: 20px; font-size: 0.9rem;">Don't have an account? <a href="register.php">Register here</a></p>
        <p style="margin-top: 10px; font-size: 0.9rem;"><a href="index.php">Back to Home</a></p>
    </div>
</body>
</html>
