<?php
// index.php
require_once 'includes/db.php';
require_once 'includes/functions.php';
include 'includes/header.php';
?>

<!-- Hero Section -->
<style>
    .hero {
        background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url('images/hero/hero-banner.jpg') no-repeat center center/cover;
        height: 80vh;
        min-height: 500px;
        display: flex;
        align-items: center;
        color: var(--white);
        position: relative;
    }
    .hero-content {
        max-width: 600px;
    }
    .hero h1 {
        font-size: 3.5rem;
        color: var(--white);
        margin-bottom: 20px;
        line-height: 1.2;
    }
    .hero h1 span {
        color: var(--secondary-green);
    }
    .hero p {
        font-size: 1.1rem;
        margin-bottom: 30px;
    }
    .hero-stats-banner {
        background: rgba(255, 255, 255, 0.95);
        border-radius: var(--border-radius);
        padding: 20px 30px;
        display: flex;
        justify-content: space-around;
        flex-wrap: wrap;
        gap: 20px;
        position: absolute;
        bottom: -40px;
        left: 0;
        right: 0;
        margin: 0 auto;
        width: 90%;
        max-width: 1200px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        z-index: 10;
        color: var(--text-dark);
    }
    .hero-stat-item {
        display: flex;
        align-items: center;
        gap: 15px;
    }
    .hero-stat-item .icon {
        color: var(--primary-green);
        font-size: 24px;
    }
    .hero-stat-item h4 {
        margin: 0;
        font-size: 1rem;
        color: var(--dark-green);
    }
    .hero-stat-item p {
        margin: 0;
        font-size: 0.8rem;
        color: var(--text-light);
    }
    
    /* Section padding adjustments */
    .section-padding {
        padding: 100px 0 60px;
    }
    .section-title {
        text-align: center;
        margin-bottom: 50px;
    }
    .section-title h2 {
        font-size: 2.2rem;
        display: inline-block;
        position: relative;
    }
    .section-title h2::after {
        content: '';
        position: absolute;
        width: 60%;
        height: 3px;
        background-color: var(--primary-green);
        bottom: -10px;
        left: 20%;
    }
    
    /* Why Choose Us styles */
    .about-section {
        background-color: var(--white);
        padding: 60px 0;
    }
    .about-content {
        display: flex;
        align-items: center;
        gap: 50px;
    }
    .about-image {
        flex: 1;
        border-radius: var(--border-radius);
        overflow: hidden;
    }
    .about-image img {
        width: 100%;
        border-radius: var(--border-radius);
        display: block;
    }
    .about-text {
        flex: 1;
    }
    .stats-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
        margin-top: 30px;
    }
    .stat-box {
        border: 1px solid #eee;
        padding: 20px;
        border-radius: var(--border-radius);
        display: flex;
        align-items: center;
        gap: 15px;
    }
    .stat-box .icon {
        color: var(--primary-green);
        font-size: 24px;
    }
</style>

<section class="hero fade-in">
    <div class="container">
        <div class="hero-content slide-up delay-1">
            <h1>Smart Agricultural<br><span>Crops Management System</span></h1>
            <p>Manage crops, irrigation, fertilizers and production digitally with ease and improve your farming productivity.</p>
            <div>
                <a href="register.php" class="btn btn-primary">Get Started</a>
                <a href="about.php" class="btn btn-outline" style="color: var(--white); border-color: var(--white);">Learn More</a>
            </div>
        </div>
    </div>
    
    <div class="hero-stats-banner slide-up delay-2">
        <div class="hero-stat-item">
            <div class="icon"><i class="fas fa-leaf"></i></div>
            <div>
                <h4>Crop Management</h4>
                <p>Track your crops<br>in real-time</p>
            </div>
        </div>
        <div class="hero-stat-item">
            <div class="icon"><i class="fas fa-tint"></i></div>
            <div>
                <h4>Irrigation Scheduling</h4>
                <p>Smart watering<br>reminders</p>
            </div>
        </div>
        <div class="hero-stat-item">
            <div class="icon"><i class="fas fa-seedling"></i></div>
            <div>
                <h4>Fertilizer Management</h4>
                <p>Get the best fertilizer<br>recommendations</p>
            </div>
        </div>
        <div class="hero-stat-item">
            <div class="icon"><i class="fas fa-chart-bar"></i></div>
            <div>
                <h4>Production Tracking</h4>
                <p>Track yield and<br>production easily</p>
            </div>
        </div>
    </div>
</section>

<!-- Why Choose Us -->
<section class="section-padding fade-in delay-3">
    <div class="container">
        <div class="section-title">
            <h2>Why Choose <span>AgroCulture?</span></h2>
        </div>
        <div class="features-grid">
            <div class="card">
                <div class="card-icon"><i class="fas fa-chart-line" style="color: var(--primary-green); font-size: 24px;"></i></div>
                <h3>Increase Productivity</h3>
                <p>Use smart tools and insights to improve crop productivity.</p>
            </div>
            <div class="card">
                <div class="card-icon"><i class="fas fa-shield-alt" style="color: var(--primary-green); font-size: 24px;"></i></div>
                <h3>Better Management</h3>
                <p>Manage your farm activities, records and schedules easily.</p>
            </div>
            <div class="card">
                <div class="card-icon"><i class="fas fa-hand-holding-usd" style="color: var(--primary-green); font-size: 24px;"></i></div>
                <h3>Save Time & Cost</h3>
                <p>Automate tasks and reduce manual work and expenses.</p>
            </div>
            <div class="card">
                <div class="card-icon"><i class="fas fa-users" style="color: var(--primary-green); font-size: 24px;"></i></div>
                <h3>Expert Guidance</h3>
                <p>Get recommendations from agriculture experts.</p>
            </div>
        </div>
    </div>
</section>

<!-- About Us Preview -->
<section class="about-section fade-in">
    <div class="container">
        <div class="about-content">
            <div class="about-image">
                <img src="images/about/farmer.jpg" alt="Farmer using tablet">
            </div>
            <div class="about-text">
                <h5 style="color: var(--primary-green); font-weight: 600; font-family: 'Poppins', sans-serif;">ABOUT US</h5>
                <h2 style="font-size: 2rem;">Empowering Farmers with <span style="color: var(--primary-green);">Technology</span></h2>
                <p>AgroCulture is a digital platform designed to help farmers manage crops, irrigation, fertilizers and production efficiently. Our mission is to empower farmers by providing smart solutions for better yield and sustainable farming.</p>
                <a href="about.php" class="btn btn-primary" style="margin-top: 15px;">Know More About Us</a>
                
                <div class="stats-grid">
                    <div class="stat-box">
                        <div class="icon"><i class="fas fa-users"></i></div>
                        <div>
                            <h3 style="margin: 0; font-size: 1.5rem;">1000+</h3>
                            <p style="margin: 0; font-size: 0.8rem; color: var(--text-light);">Happy Farmers</p>
                        </div>
                    </div>
                    <div class="stat-box">
                        <div class="icon"><i class="fas fa-seedling"></i></div>
                        <div>
                            <h3 style="margin: 0; font-size: 1.5rem;">50+</h3>
                            <p style="margin: 0; font-size: 0.8rem; color: var(--text-light);">Crops Managed</p>
                        </div>
                    </div>
                    <div class="stat-box">
                        <div class="icon"><i class="far fa-calendar-check"></i></div>
                        <div>
                            <h3 style="margin: 0; font-size: 1.5rem;">500+</h3>
                            <p style="margin: 0; font-size: 0.8rem; color: var(--text-light);">Schedules Created</p>
                        </div>
                    </div>
                    <div class="stat-box">
                        <div class="icon"><i class="fas fa-chart-line"></i></div>
                        <div>
                            <h3 style="margin: 0; font-size: 1.5rem;">200+</h3>
                            <p style="margin: 0; font-size: 0.8rem; color: var(--text-light);">Production Records</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
