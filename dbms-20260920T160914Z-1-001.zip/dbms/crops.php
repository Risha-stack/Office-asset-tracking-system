<?php
// crops.php
require_once 'includes/db.php';
require_once 'includes/functions.php';
include 'includes/header.php';
?>

<style>
    .page-header {
        background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('images/hero/farming-bg.jpg') no-repeat center center/cover;
        height: 300px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--white);
        text-align: center;
    }
    .page-header h1 {
        font-size: 2.5rem;
        color: var(--white);
        margin-bottom: 10px;
    }
    .breadcrumb {
        font-size: 1rem;
    }
    .breadcrumb a {
        color: var(--secondary-green);
    }
    .section-padding {
        padding: 80px 0;
    }
    
    .crops-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 30px;
    }
</style>

<div class="page-header fade-in">
    <div class="container">
        <h1>Crop Categories</h1>
        <div class="breadcrumb">
            <a href="index.php">Home</a> / Crops
        </div>
    </div>
</div>

<section class="section-padding">
    <div class="container">
        <div class="crops-grid">
            <!-- Rice -->
            <div class="crop-card fade-in">
                <img src="images/crops/rice.jpg" alt="Rice" class="crop-card-img">
                <div class="crop-card-body">
                    <h3>Rice</h3>
                    <div class="crop-card-details">
                        <p><strong>Season:</strong> <span>Kharif (Monsoon)</span></p>
                        <p><strong>Soil Type:</strong> <span>Clay/Clay Loam</span></p>
                        <p><strong>Water Req:</strong> <span>High (Standing water)</span></p>
                        <p><strong>Duration:</strong> <span>100-150 days</span></p>
                    </div>
                </div>
            </div>
            
            <!-- Wheat -->
            <div class="crop-card fade-in delay-1">
                <img src="images/crops/wheat.jpg" alt="Wheat" class="crop-card-img">
                <div class="crop-card-body">
                    <h3>Wheat</h3>
                    <div class="crop-card-details">
                        <p><strong>Season:</strong> <span>Rabi (Winter)</span></p>
                        <p><strong>Soil Type:</strong> <span>Loamy</span></p>
                        <p><strong>Water Req:</strong> <span>Medium</span></p>
                        <p><strong>Duration:</strong> <span>110-130 days</span></p>
                    </div>
                </div>
            </div>
            
            <!-- Sugarcane -->
            <div class="crop-card fade-in delay-2">
                <img src="images/crops/sugarcane.jpg" alt="Sugarcane" class="crop-card-img">
                <div class="crop-card-body">
                    <h3>Sugarcane</h3>
                    <div class="crop-card-details">
                        <p><strong>Season:</strong> <span>All Year (Perennial)</span></p>
                        <p><strong>Soil Type:</strong> <span>Deep, well-drained</span></p>
                        <p><strong>Water Req:</strong> <span>High</span></p>
                        <p><strong>Duration:</strong> <span>10-18 months</span></p>
                    </div>
                </div>
            </div>
            
            <!-- Cotton -->
            <div class="crop-card fade-in">
                <img src="images/crops/cotton.jpg" alt="Cotton" class="crop-card-img">
                <div class="crop-card-body">
                    <h3>Cotton</h3>
                    <div class="crop-card-details">
                        <p><strong>Season:</strong> <span>Kharif</span></p>
                        <p><strong>Soil Type:</strong> <span>Black Soil</span></p>
                        <p><strong>Water Req:</strong> <span>Moderate</span></p>
                        <p><strong>Duration:</strong> <span>150-180 days</span></p>
                    </div>
                </div>
            </div>
            
            <!-- Vegetables -->
            <div class="crop-card fade-in delay-1">
                <img src="images/crops/vegetables.jpg" alt="Vegetables" class="crop-card-img">
                <div class="crop-card-body">
                    <h3>Vegetables</h3>
                    <div class="crop-card-details">
                        <p><strong>Season:</strong> <span>Various</span></p>
                        <p><strong>Soil Type:</strong> <span>Sandy Loam</span></p>
                        <p><strong>Water Req:</strong> <span>Frequent, Moderate</span></p>
                        <p><strong>Duration:</strong> <span>60-120 days</span></p>
                    </div>
                </div>
            </div>
            
            <!-- Fruits -->
            <div class="crop-card fade-in delay-2">
                <img src="images/crops/fruits.jpg" alt="Fruits" class="crop-card-img">
                <div class="crop-card-body">
                    <h3>Fruits (Orchards)</h3>
                    <div class="crop-card-details">
                        <p><strong>Season:</strong> <span>Perennial</span></p>
                        <p><strong>Soil Type:</strong> <span>Well-drained</span></p>
                        <p><strong>Water Req:</strong> <span>Varies by fruit</span></p>
                        <p><strong>Duration:</strong> <span>Years</span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
