<?php
// admin/manage_farmers.php
require_once '../includes/db.php';
include 'admin_header.php';

// Delete user
if(isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM users WHERE id = $id");
    header("Location: manage_farmers.php");
    exit();
}
?>

<div class="admin-card">
    <h3 style="margin-bottom: 20px; color: var(--dark-green);">Manage Farmers</h3>
    <table style="width: 100%; text-align: left; border-collapse: collapse;">
        <thead>
            <tr>
                <th style="padding: 10px; background: var(--gray-bg);">ID</th>
                <th style="padding: 10px; background: var(--gray-bg);">Name</th>
                <th style="padding: 10px; background: var(--gray-bg);">Email</th>
                <th style="padding: 10px; background: var(--gray-bg);">Location</th>
                <th style="padding: 10px; background: var(--gray-bg);">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $users = $conn->query("SELECT * FROM users ORDER BY id DESC");
            if($users->num_rows > 0) {
                while($user = $users->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$user['id']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$user['fullname']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$user['email']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$user['farm_location']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>
                            <a href='manage_farmers.php?delete={$user['id']}' onclick='return confirm(\"Delete this farmer?\")' style='color: red;'><i class='fas fa-trash'></i></a>
                          </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5' style='text-align:center;'>No farmers found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<?php include 'admin_footer.php'; ?>
