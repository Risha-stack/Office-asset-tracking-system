<?php
// admin/admin_dashboard.php
require_once '../includes/db.php';
include 'admin_header.php';

// Fetch stats
$total_farmers = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];
$total_crops = $conn->query("SELECT COUNT(*) as count FROM crops")->fetch_assoc()['count'];
$total_production = $conn->query("SELECT SUM(quantity_produced) as total FROM production")->fetch_assoc()['total'];
$total_production = $total_production ? $total_production : 0;
?>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px;">
    <div class="admin-card" style="border-left: 4px solid var(--primary-green); display: flex; align-items: center; gap: 20px;">
        <i class="fas fa-users" style="font-size: 30px; color: var(--primary-green);"></i>
        <div>
            <h4 style="color: var(--text-light); margin-bottom: 5px;">Total Farmers</h4>
            <h2 style="margin: 0; color: var(--dark-green);"><?= $total_farmers ?></h2>
        </div>
    </div>
    
    <div class="admin-card" style="border-left: 4px solid var(--secondary-green); display: flex; align-items: center; gap: 20px;">
        <i class="fas fa-seedling" style="font-size: 30px; color: var(--secondary-green);"></i>
        <div>
            <h4 style="color: var(--text-light); margin-bottom: 5px;">Total Crops</h4>
            <h2 style="margin: 0; color: var(--dark-green);"><?= $total_crops ?></h2>
        </div>
    </div>
    
    <div class="admin-card" style="border-left: 4px solid #f39c12; display: flex; align-items: center; gap: 20px;">
        <i class="fas fa-chart-bar" style="font-size: 30px; color: #f39c12;"></i>
        <div>
            <h4 style="color: var(--text-light); margin-bottom: 5px;">Total Production (kg)</h4>
            <h2 style="margin: 0; color: var(--dark-green);"><?= number_format($total_production, 2) ?></h2>
        </div>
    </div>
</div>

<div class="admin-card">
    <h3 style="margin-bottom: 20px; color: var(--dark-green);">Recent Farmers Joined</h3>
    <table style="width: 100%; text-align: left; border-collapse: collapse;">
        <thead>
            <tr>
                <th style="padding: 10px; background: var(--gray-bg);">Name</th>
                <th style="padding: 10px; background: var(--gray-bg);">Email</th>
                <th style="padding: 10px; background: var(--gray-bg);">Location</th>
                <th style="padding: 10px; background: var(--gray-bg);">Joined</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $users = $conn->query("SELECT * FROM users ORDER BY id DESC LIMIT 5");
            if($users->num_rows > 0) {
                while($user = $users->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$user['fullname']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$user['email']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$user['farm_location']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$user['created_at']}</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4' style='text-align:center;'>No farmers found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<?php include 'admin_footer.php'; ?>
