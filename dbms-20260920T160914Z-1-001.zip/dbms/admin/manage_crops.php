<?php
// admin/manage_crops.php
require_once '../includes/db.php';
include 'admin_header.php';

// Delete crop
if(isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM crops WHERE id = $id");
    header("Location: manage_crops.php");
    exit();
}
?>

<div class="admin-card">
    <h3 style="margin-bottom: 20px; color: var(--dark-green);">Manage Crops Database</h3>
    <table style="width: 100%; text-align: left; border-collapse: collapse;">
        <thead>
            <tr>
                <th style="padding: 10px; background: var(--gray-bg);">ID</th>
                <th style="padding: 10px; background: var(--gray-bg);">Farmer</th>
                <th style="padding: 10px; background: var(--gray-bg);">Crop Name</th>
                <th style="padding: 10px; background: var(--gray-bg);">Category</th>
                <th style="padding: 10px; background: var(--gray-bg);">Planting Date</th>
                <th style="padding: 10px; background: var(--gray-bg);">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $crops = $conn->query("SELECT c.*, u.fullname FROM crops c JOIN users u ON c.user_id = u.id ORDER BY c.id DESC");
            if($crops->num_rows > 0) {
                while($crop = $crops->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$crop['id']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$crop['fullname']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$crop['crop_name']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$crop['crop_category']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$crop['planting_date']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>
                            <a href='manage_crops.php?delete={$crop['id']}' onclick='return confirm(\"Delete this crop record?\")' style='color: red;'><i class='fas fa-trash'></i></a>
                          </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6' style='text-align:center;'>No crops found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<?php include 'admin_footer.php'; ?>
