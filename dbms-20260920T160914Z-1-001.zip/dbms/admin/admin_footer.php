<?php
// admin/admin_footer.php
?>
            </div> <!-- End content-body -->
        </div> <!-- End main-content -->
    </div> <!-- End admin-layout -->
</body>
</html>
