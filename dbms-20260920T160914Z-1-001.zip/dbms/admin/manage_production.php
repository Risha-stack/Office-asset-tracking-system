<?php
// admin/manage_production.php
require_once '../includes/db.php';
include 'admin_header.php';
?>

<div class="admin-card">
    <h3 style="margin-bottom: 20px; color: var(--dark-green);">Production Reports Overview</h3>
    <table style="width: 100%; text-align: left; border-collapse: collapse;">
        <thead>
            <tr>
                <th style="padding: 10px; background: var(--gray-bg);">Farmer</th>
                <th style="padding: 10px; background: var(--gray-bg);">Crop</th>
                <th style="padding: 10px; background: var(--gray-bg);">Date</th>
                <th style="padding: 10px; background: var(--gray-bg);">Quantity (kg)</th>
                <th style="padding: 10px; background: var(--gray-bg);">Market Price</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $records = $conn->query("SELECT p.*, c.crop_name, u.fullname FROM production p JOIN crops c ON p.crop_id = c.id JOIN users u ON c.user_id = u.id ORDER BY p.harvest_date DESC");
            if($records->num_rows > 0) {
                while($record = $records->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$record['fullname']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$record['crop_name']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$record['harvest_date']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$record['quantity_produced']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>$" . number_format($record['market_price'], 2) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5' style='text-align:center;'>No production records found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<?php include 'admin_footer.php'; ?>
