<?php
// admin/admin_header.php
require_once '../includes/session.php';
requireAdminLogin();
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - AgroCulture</title>
    
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/animations.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        .admin-layout {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 250px;
            background: var(--dark-green);
            color: var(--white);
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-menu {
            list-style: none;
            padding: 20px 0;
        }
        .sidebar-menu li a {
            display: block;
            padding: 15px 25px;
            color: #ccc;
            text-decoration: none;
            transition: var(--transition);
        }
        .sidebar-menu li a:hover, .sidebar-menu li a.active {
            background: rgba(255,255,255,0.1);
            color: var(--white);
            border-left: 4px solid var(--secondary-green);
        }
        .sidebar-menu li a i {
            width: 25px;
        }
        .main-content {
            flex: 1;
            margin-left: 250px;
            background: var(--bg-color);
        }
        .top-navbar {
            background: var(--white);
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .content-body {
            padding: 30px;
        }
        .admin-card {
            background: var(--white);
            padding: 20px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            margin-bottom: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid var(--gray-bg);
        }
        th { background: var(--gray-bg); }
    </style>
</head>
<body>
    <div class="admin-layout">
        <div class="sidebar">
            <div class="sidebar-header">
                <h2><i class="fas fa-leaf"></i> Admin</h2>
            </div>
            <ul class="sidebar-menu">
                <li><a href="admin_dashboard.php" class="<?= $current_page == 'admin_dashboard.php' ? 'active' : '' ?>"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="manage_farmers.php" class="<?= $current_page == 'manage_farmers.php' ? 'active' : '' ?>"><i class="fas fa-users"></i> Manage Farmers</a></li>
                <li><a href="manage_crops.php" class="<?= $current_page == 'manage_crops.php' ? 'active' : '' ?>"><i class="fas fa-seedling"></i> Manage Crops</a></li>
                <li><a href="manage_fertilizers.php" class="<?= $current_page == 'manage_fertilizers.php' ? 'active' : '' ?>"><i class="fas fa-flask"></i> Fertilizers</a></li>
                <li><a href="manage_production.php" class="<?= $current_page == 'manage_production.php' ? 'active' : '' ?>"><i class="fas fa-chart-line"></i> Production Reports</a></li>
            </ul>
        </div>
        
        <div class="main-content">
            <div class="top-navbar">
                <div><h3>Dashboard</h3></div>
                <div>
                    <span><i class="fas fa-user-circle"></i> Admin</span>
                    <a href="admin_logout.php" class="btn btn-outline" style="margin-left: 15px; padding: 5px 15px;">Logout</a>
                </div>
            </div>
            <div class="content-body fade-in">
