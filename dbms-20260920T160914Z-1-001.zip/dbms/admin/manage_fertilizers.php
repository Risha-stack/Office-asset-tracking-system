<?php
// admin/manage_fertilizers.php
require_once '../includes/db.php';
include 'admin_header.php';
?>

<div class="admin-card">
    <h3 style="margin-bottom: 20px; color: var(--dark-green);">Manage Fertilizer Recommendations</h3>
    <table style="width: 100%; text-align: left; border-collapse: collapse;">
        <thead>
            <tr>
                <th style="padding: 10px; background: var(--gray-bg);">ID</th>
                <th style="padding: 10px; background: var(--gray-bg);">Name</th>
                <th style="padding: 10px; background: var(--gray-bg);">Crop Type</th>
                <th style="padding: 10px; background: var(--gray-bg);">Quantity</th>
                <th style="padding: 10px; background: var(--gray-bg);">Instructions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $items = $conn->query("SELECT * FROM fertilizers");
            if($items->num_rows > 0) {
                while($item = $items->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$item['id']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$item['fertilizer_name']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$item['crop_type']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$item['quantity']}</td>";
                    echo "<td style='padding: 10px; border-bottom: 1px solid var(--gray-bg);'>{$item['instructions']}</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5' style='text-align:center;'>No recommendations found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<?php include 'admin_footer.php'; ?>
