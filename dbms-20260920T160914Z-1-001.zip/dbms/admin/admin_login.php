<?php
// admin/admin_login.php
require_once '../includes/db.php';
require_once '../includes/functions.php';
session_start();

if (isset($_SESSION['admin_id'])) {
    header("Location: admin_dashboard.php");
    exit();
}

$error_msg = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = sanitizeInput($_POST['username']);
    $password = $_POST['password'];

    $sql = "SELECT id, username, password FROM admin WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['admin_id'] = $row['id'];
            $_SESSION['admin_username'] = $row['username'];
            header("Location: admin_dashboard.php");
            exit();
        } else {
            $error_msg = "Invalid password.";
        }
    } else {
        $error_msg = "Admin not found.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login - AgroCulture</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/animations.css">
    <style>
        body {
            background-color: var(--dark-green);
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        .auth-container {
            background: var(--white);
            padding: 40px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }
        .auth-logo {
            color: var(--dark-green);
            font-size: 30px;
            margin-bottom: 10px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="auth-container fade-in">
        <div class="auth-logo"><i class="fas fa-shield-alt"></i> Admin Panel</div>
        <h2 style="margin-bottom: 20px; color: var(--dark-green);">Login</h2>
        
        <?php if(!empty($error_msg)) echo displayAlert($error_msg, 'error'); ?>
        
        <form action="admin_login.php" method="POST" style="text-align: left;">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 10px;">Login</button>
        </form>
        <p style="margin-top: 20px;"><a href="../index.php">Back to Main Website</a></p>
    </div>
</body>
</html>
