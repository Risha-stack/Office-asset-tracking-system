<?php
// profile.php
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_once 'includes/session.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$success_msg = '';
$error_msg = '';

// Handle form submission for profile update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = sanitizeInput($_POST['fullname']);
    $email = sanitizeInput($_POST['email']);
    $farm_location = sanitizeInput($_POST['farm_location']);
    
    // Optional: Password update
    $password_update = "";
    if(!empty($_POST['new_password'])) {
        $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
        $password_update = ", password = '$new_password'";
    }

    $sql = "UPDATE users SET fullname = '$fullname', email = '$email', farm_location = '$farm_location' $password_update WHERE id = $user_id";
    
    if ($conn->query($sql) === TRUE) {
        $success_msg = "Profile updated successfully!";
        // Update session variables if needed
        $_SESSION['user_name'] = $fullname;
    } else {
        $error_msg = "Error updating profile: " . $conn->error;
    }
}

// Fetch current user details
$user_query = $conn->query("SELECT * FROM users WHERE id = $user_id");
$user = $user_query->fetch_assoc();

include 'includes/header.php';
?>

<div class="container fade-in" style="padding: 40px 0;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2>My Profile</h2>
        <a href="dashboard.php" class="btn btn-outline">Back to Dashboard</a>
    </div>

    <div class="card" style="max-width: 600px; margin: 0 auto;">
        <?php 
            if(!empty($success_msg)) echo displayAlert($success_msg, 'success');
            if(!empty($error_msg)) echo displayAlert($error_msg, 'error');
        ?>
        
        <div style="text-align: center; margin-bottom: 30px;">
            <div style="width: 100px; height: 100px; background-color: var(--primary-green); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 40px; margin: 0 auto 15px;">
                <i class="fas fa-user"></i>
            </div>
            <h3 style="margin-bottom: 5px;"><?php echo htmlspecialchars($user['fullname']); ?></h3>
            <p style="color: var(--text-light);">Member since <?php echo date('F Y', strtotime($user['created_at'])); ?></p>
        </div>

        <form action="profile.php" method="POST">
            <div class="form-group">
                <label>Full Name *</label>
                <input type="text" name="fullname" class="form-control" value="<?php echo htmlspecialchars($user['fullname']); ?>" required>
            </div>
            <div class="form-group">
                <label>Email Address *</label>
                <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>
            <div class="form-group">
                <label>Farm Location *</label>
                <input type="text" name="farm_location" class="form-control" value="<?php echo htmlspecialchars($user['farm_location']); ?>" required>
            </div>
            
            <hr style="border: 0; border-top: 1px solid var(--gray-bg); margin: 30px 0;">
            <h4 style="margin-bottom: 15px; color: var(--dark-green);">Change Password (Optional)</h4>
            
            <div class="form-group">
                <label>New Password</label>
                <input type="password" name="new_password" class="form-control" placeholder="Leave blank to keep current password">
            </div>
            
            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 20px;">Update Profile</button>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
