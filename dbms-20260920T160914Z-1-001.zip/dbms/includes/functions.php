<?php
// includes/functions.php

function sanitizeInput($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $conn->real_escape_string($data);
}

function displayAlert($message, $type = 'success') {
    return "<div class='alert alert-{$type}'>{$message}</div>";
}
?>
