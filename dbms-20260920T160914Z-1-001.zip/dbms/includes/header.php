<?php
// includes/header.php
require_once 'session.php';
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AgroCulture - Smart Agricultural Management System</title>
    
    <!-- CSS -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/navbar.css">
    <link rel="stylesheet" href="css/cards.css">
    <link rel="stylesheet" href="css/animations.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

    <!-- Top Bar -->
    <div class="top-bar">
        <div class="container">
            <div class="top-bar-left">
                <span><i class="fas fa-envelope"></i> info@agroculture.com</span>
                <span><i class="fas fa-phone-alt"></i> +91 98765 43210</span>
            </div>
            <div class="top-bar-right">
                <span>Follow Us:</span>
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-linkedin-in"></i></a>
            </div>
        </div>
    </div>

    <!-- Navigation Bar -->
    <header>
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <i class="fas fa-leaf"></i>
                    <div>
                        AgroCulture<br>
                        <span style="font-size: 10px; font-weight: 400; color: #555;">Grow Better, Live Better</span>
                    </div>
                </a>

                <ul class="nav-links">
                    <li><a href="index.php" class="<?= $current_page == 'index.php' ? 'active' : '' ?>">Home</a></li>
                    <li><a href="about.php" class="<?= $current_page == 'about.php' ? 'active' : '' ?>">About</a></li>
                    <li><a href="crops.php" class="<?= $current_page == 'crops.php' ? 'active' : '' ?>">Crops</a></li>
                    <li><a href="irrigation.php" class="<?= $current_page == 'irrigation.php' ? 'active' : '' ?>">Irrigation</a></li>
                    <li><a href="fertilizer.php" class="<?= $current_page == 'fertilizer.php' ? 'active' : '' ?>">Fertilizer</a></li>
                    <li><a href="production.php" class="<?= $current_page == 'production.php' ? 'active' : '' ?>">Production</a></li>
                    <li><a href="contact.php" class="<?= $current_page == 'contact.php' ? 'active' : '' ?>">Contact</a></li>
                </ul>

                <div class="nav-buttons">
                    <?php if(isLoggedIn()): ?>
                        <a href="dashboard.php" class="btn btn-outline">Dashboard</a>
                        <a href="logout.php" class="btn btn-primary">Logout</a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-outline">Login</a>
                        <a href="register.php" class="btn btn-primary">Register</a>
                    <?php endif; ?>
                </div>
                
                <div class="mobile-menu-btn">
                    <i class="fas fa-bars"></i>
                </div>
            </nav>
        </div>
    </header>
