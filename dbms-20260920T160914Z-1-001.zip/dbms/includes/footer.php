<?php
// includes/footer.php
?>
    <footer>
        <div class="container">
            <div class="footer-grid">
                <div class="footer-col">
                    <h3>Our Mission</h3>
                    <p>To provide innovative tools for sustainable agriculture, enabling farmers to make data-driven decisions and optimize their crop yield.</p>
                </div>
                
                <div class="footer-col">
                    <h3>Our Vision</h3>
                    <p>To be a leading platform in digital farming solutions, connecting traditional farming wisdom with modern technology.</p>
                </div>
                
                <div class="footer-col">
                    <h3>Our Goal</h3>
                    <p>To improve farmers' income and quality of life by reducing resource wastage and increasing overall productivity.</p>
                </div>
                
                <div class="footer-col">
                    <h3>Quick Links</h3>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="contact.php">Contact Support</a></li>
                        <li><a href="login.php">Farmer Login</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; <?= date('Y') ?> AgroCulture - Smart Agricultural Crops Management System. All Rights Reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script>
        // Mobile Menu Toggle
        const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
        const navLinks = document.querySelector('.nav-links');

        if(mobileMenuBtn) {
            mobileMenuBtn.addEventListener('click', () => {
                navLinks.classList.toggle('active');
            });
        }
    </script>
</body>
</html>
