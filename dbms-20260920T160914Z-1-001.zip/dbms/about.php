<?php
// about.php
require_once 'includes/db.php';
require_once 'includes/functions.php';
include 'includes/header.php';
?>

<style>
    .page-header {
        background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('images/hero/farming-bg.jpg') no-repeat center center/cover;
        height: 300px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--white);
        text-align: center;
    }
    .page-header h1 {
        font-size: 2.5rem;
        color: var(--white);
        margin-bottom: 10px;
    }
    .breadcrumb {
        font-size: 1rem;
    }
    .breadcrumb a {
        color: var(--secondary-green);
    }
    .section-padding {
        padding: 80px 0;
    }
    
    .team-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 30px;
        margin-top: 40px;
    }
    .team-member {
        text-align: center;
        background: var(--white);
        padding: 30px;
        border-radius: var(--border-radius);
        box-shadow: var(--shadow);
    }
    .team-member img {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        object-fit: cover;
        margin-bottom: 20px;
        border: 4px solid var(--gray-bg);
    }
</style>

<div class="page-header fade-in">
    <div class="container">
        <h1>About Us</h1>
        <div class="breadcrumb">
            <a href="index.php">Home</a> / About
        </div>
    </div>
</div>

<section class="section-padding">
    <div class="container">
        <div class="about-content" style="display: flex; gap: 50px; align-items: center;">
            <div class="about-text" style="flex: 1;">
                <h2 style="color: var(--dark-green);">Our Mission to Transform <span style="color: var(--primary-green);">Agriculture</span></h2>
                <p>AgroCulture was founded with a simple yet powerful goal: to bring the benefits of modern technology to the traditional farming sector. We believe that with the right tools, farmers can significantly improve their yield, manage their resources better, and lead more prosperous lives.</p>
                <p>Our platform provides comprehensive solutions for managing crops from seed to sale. Whether it's scheduling irrigation to save water or finding the right fertilizer, AgroCulture is the farmer's digital companion.</p>
                
                <h3 style="margin-top: 30px; color: var(--dark-green);">Objectives</h3>
                <ul style="list-style-position: inside; color: var(--text-light); line-height: 1.8;">
                    <li>Digitize crop management processes for better tracking.</li>
                    <li>Provide smart irrigation schedules to optimize water usage.</li>
                    <li>Recommend suitable fertilizers based on crop types.</li>
                    <li>Track production and market prices effectively.</li>
                </ul>
            </div>
            <div class="about-image" style="flex: 1;">
                <img src="images/about/smart-farming.jpg" alt="Smart Farming" style="width: 100%; border-radius: var(--border-radius); box-shadow: var(--shadow);">
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
